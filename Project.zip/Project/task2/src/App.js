
import './App.css';
import Transaction from './Component/Transaction';
import './Component/Style.css';
function App() {
  return (
    <div className="App">
     <Transaction/>
    </div>
  );
}

export default App;
