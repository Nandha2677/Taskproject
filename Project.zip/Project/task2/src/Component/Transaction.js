import React, { useEffect, useState } from "react";
import "./Style.css";
import imge from './Images/profile.jpg';

const Transaction = () => {
  const [record, setRecord] = useState([]);

  useEffect(() => {
    fetch("/data.json")
      .then((response) => response.json())
      .then((data) => setRecord(data))
      .catch((error) => console.error("Error data:", error));
  }, []);

  return (
     <div id="main">
              <div id="title">
                <h2>Last Transactions</h2>
                <h3>See All</h3>
              </div>
      <tbody>
          {record.map((course, index) => (
            <tr key={index}>
                  <div id="one">
                      <img id="small" src={imge}></img>
                      <div id="pp">
                    <div id="p1">
                      {course.name1}
                      {course.percent1}
                      </div>
                      <div id="p2">
                      {course.date1}
                      {course.rate1}
                      </div>
                      </div>
                  </div>
                  <div id="two">
                  <div id="p3">
                      <span>{course.name2}</span>
                      {course.percent2}
                      </div>
                      <div id="p4">
                      {course.date2}
                      {course.rate2}
                      </div>
                 
                  <div id="three">
                  <div id="p5">
                      <span>{course.name3}</span>
                      {course.percent3}
                      </div>
                      <div id="p6">
                      {course.date3}
                      {course.rate3}
                      </div>
                  </div>
                  </div>
                  
            </tr>
          ))}
        </tbody>
    </div>
  );
};

export default Transaction;

<div id='p1'>
<div id='p2'>
        <h3>Last Transactions</h3>
         <h3>See All</h3>
    </div>
<div id='part4'>

    
    <div id='p3'>
       <section>
        <div id='pro1'>
        <h1>Aokiji</h1>
        <h2>28 Feb 2023 . 06:23PM</h2>
        </div>
        <div id='pro2'>
            
            <h1>+$13.00</h1>
            <h2>Received</h2>
        </div>
       </section>
       <section>
        <div id='pro1'>
        <h1>Kizaru</h1>
        <h2>28 Feb 2023 . 06:23PM</h2>
        </div>
        <div id='pro2'>
            
            <h1>-$9.00</h1>
            <h2>Received</h2>
        </div>
       </section>
       <section>
        <div id='pro1'>
        <h1>Akainu</h1>
        <h2>28 Feb 2023 . 06:23PM</h2>
        </div>
        <div id='pro2'>
            
            <h1>+$20.00</h1>
            <h2>Received</h2>
        </div>
       </section>
    </div>
</div>
</div>