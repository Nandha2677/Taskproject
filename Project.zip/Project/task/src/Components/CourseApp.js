import React from 'react';
export default function CourseApp() {
    return(
        <div id='part2'>
            <div id='th'>
                <h2>My Courses</h2>
                <h2>View All</h2>
            </div>
            <div id='th1'>
                <h2> Course Name</h2>
                <h2>Start Date</h2>
                <h2>Lesson Completed</h2>
                <h2>Duration</h2>
            </div>
            <div id='t1'>
                <h2>Basic Algorithm</h2>
                <h2>27 Jan,2023</h2>
                <h2>10/25(48%)</h2>
                <h2>14h 38m 56s</h2>
            </div>
            <div id='t2'>
                <h2>Web Development</h2>
                <h2>23 Feb,2023</h2>
                <h2>40/45(97%)</h2>
                <h2>36h 30m 00s</h2>
            </div>
            <div id='t3'>
                <h2>Basic Data Science</h2>
                <h2>14 Jan,2023</h2>
                <h2>9/37(40%)</h2>
                <h2>37h 00m 00s</h2>
            </div>
            <div id='t4'>
                <h2>UI/UX Design</h2>
                <h2>19 Feb,2023</h2>
                <h2>26/32(84%)</h2>
                <h2>16h 40m 50s</h2>
            </div>
            <div id='t5'>
                <h2>Project Management</h2>
                <h2>27 Jan,2023</h2>
                <h2>14/19(89%)</h2>
                <h2>13h 20m 00s</h2>
            </div>
        </div>
    )
}
