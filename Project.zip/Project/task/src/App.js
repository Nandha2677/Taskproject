import './App.css';
import CourseApp from './Components/CourseApp';

function App() {
  return (
    <div className="App">
      
   
      <CourseApp/>
    
    </div>
  );
}

export default App;
