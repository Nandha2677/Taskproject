import React from 'react';
export default function Responsive() {
    return(
        <div id='part5'>
           <nav>
           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
  <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
</svg> 
      <button id='btn'>Home</button>
      <button id='btn'>About</button>
      <button id='btn'>contact Us</button>
</nav>    
        <div id='body'>
            <div id='part0'>
                <button id='bt'>#Top</button>
            </div>
            <div id='part1'>
            <h1> A Responsibly As Teach Leadiung, Global Company</h1>
            <h5>Creating Superior Products & Services</h5>
            </div>
            <div id='part2'>
                <div id='content'>
            <svg id='icon' xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bookmark-star-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M2 15.5V2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.74.439L8 13.069l-5.26 2.87A.5.5 0 0 1 2 15.5M8.16 4.1a.178.178 0 0 0-.32 0l-.634 1.285a.18.18 0 0 1-.134.098l-1.42.206a.178.178 0 0 0-.098.303L6.58 6.993c.042.041.061.1.051.158L6.39 8.565a.178.178 0 0 0 .258.187l1.27-.668a.18.18 0 0 1 .165 0l1.27.668a.178.178 0 0 0 .257-.187L9.368 7.15a.18.18 0 0 1 .05-.158l1.028-1.001a.178.178 0 0 0-.098-.303l-1.42-.206a.18.18 0 0 1-.134-.098z"/>
</svg> 
            <h2>Trust Pilot</h2>
            <p>Rated Best 12.6K Reviews</p>
            </div>
            <div id='rec'>
                <h3 id='box'>Play</h3>
            </div>
            <div id='rec1'>
                <div id='subrec'>

                </div>
            </div>
            </div>
            <div id='part3'>
                <button id='btn2'>Signup to Get 50% OFF</button>
                <button id='btn3'>Explore New Products</button>
            </div>
        </div>
        </div>
    )
}