
import './App.css';
import './Components/Style.css';
import Responsive from './Components/Responsive';
function App() {
  return (
    <div className="App">
     <Responsive/>
    </div>
  );
}

export default App;
