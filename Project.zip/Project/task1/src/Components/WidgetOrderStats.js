import React, { useEffect, useState } from "react";
import "./Style.css";
import pic1 from './Images/picture1.png';
import pic2 from './Images/picture2.png';
import pic3 from './Images/picture3.png';
import pic4 from './Images/picture4.png';
const CourseTable = () => {
  const [table, setTable] = useState([]);

  useEffect(() => {
    fetch("/data.json")
      .then((response) => response.json())
      .then((data) => setTable(data))
      .catch((error) => console.error("Error data:", error));
  }, []);

  return (
    <div id="main">
      <tbody>
          {table.map((course, index) => (
            <tr key={index}>
                  
                 <div id="sub1">
                  <div id="space">
                  <h5><img src={pic1}></img></h5>
                  <span id="span1">{course.name1}</span>
                  <span id="red"> {course.percent1}</span>
                  
                 
               
                  
                   <h2 id="cost">{course.cost1}</h2>
                 
                
                 <div id="sub2">
                 <div id="space">
                <span id="span1">{course.name2}</span>
                 <span id="green">{course.percent2}</span>
                 </div>
                 
                  <h2> {course.cost2}</h2>
                 </div>
                 <div id="sub3">
                <div id="space">
                 <span id="span1">{course.name3}</span>
                 <span id="green">{course.percent3}</span>
                 </div>
                 
                   <h2>{course.cost3}</h2>
                 </div>
                 <div id="sub4">
                 <div id="space">
                <span id="span1"> {course.name4}</span>
                 <span id="red">{course.percent4}</span>
                 </div>
                 
                  <h2> {course.cost4}</h2>
                 </div>
                  </div>
                  </div>
            </tr>
          ))}
        </tbody>
    </div>
    
  );
};

export default CourseTable;








