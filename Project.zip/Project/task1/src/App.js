
import './App.css';
import WidgetOrderStats from './Components/WidgetOrderStats';
function App() {
  return (
    <div className="App">
     <WidgetOrderStats/>
    </div>
  );
}

export default App;
